const mongoose = require('mongoose');
const chat = require('./models/chat.js');


main().then(()=>{console.log("Connection Successful..")})
.catch((err)=>{console.log(err);});

async function main() {
  await mongoose.connect("mongodb://127.0.0.1:27017/whatsapp");
  }

let chats = [
    {
        from : "choti",
        to :"chotu",
        msg : "hii",
        created_at : new Date()
    },
    {
        from : "akash",
        to :"apresh",
        msg : "hello",
        created_at : new Date()
    },
    {
        from : "ankush",
        to :"aman",
        msg : "62-sector",
        created_at : new Date()
    },
    {
        from : "abhay",
        to :"chotu",
        msg : "g.b.nagar",
        created_at : new Date()
    }
]

chat.insertMany(chats);
